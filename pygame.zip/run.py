import memory

if __name__ == "__main__":
    g = memory.Game()
    g.run()
